Home Task

Задание 1. 
Выполнить задания по работе со списками:
https://webref.ru/practice/2199
https://webref.ru/practice/2198
https://webref.ru/practice/2204
https://webref.ru/practice/2206
https://webref.ru/practice/2449
https://webref.ru/practice/2451 
https://webref.ru/practice/2452 
https://webref.ru/practice/2453 

Задание 2. 
Выполнить задания по работе с таблицами:
https://webref.ru/practice/2221
https://webref.ru/practice/2493 
https://webref.ru/practice/2494 

Задание 3. 
Выполнить дополнительные задания по пройденному материалу:
https://webref.ru/individual/2358

Задание 4. Прочесть статью про чтение браузером CSS-селекторов
https://andrew-r.ru/notes/css-selectors-matching/