
Верстка секции awesome. 
При создании верстки использовать методологию БЭМ.
Каждую новую секцию верстаем во внешнем файле стилей.
Ширина ограничивающего контейнера - 1170px.
Поля - 0 15px.
Ссылка на макет в Figma:

https://www.figma.com/file/HSpUw9vcPqq9vpzzhoF2en/School-1?node-id=0%3A1


Создать репозиторий на Git Hub c названием FE33-ProgectName-Ivanov-Ivan